// MiniC program for simple addition
#include<stdio.h>
  
  int main() {
      int a;
      int b;
      int c;
      a = 10;
      b = 20;
      c = a + b;
      printf("c = %d\n", c);
      return 0;
  }