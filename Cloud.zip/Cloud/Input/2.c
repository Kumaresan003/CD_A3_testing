// MiniC program for simple comparision
#include<stdio.h>

int main() {
    int x;
    int y;
    x = 5;
    y = 10;
    if (x < y) {
        printf("x is less than y\n");
    } else {
        printf("x is not less than y\n");
    }
    return 0;
}